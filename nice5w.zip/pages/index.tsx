import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

export default function Home() {
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  const searchPlayer = async () => {
    if (!username) return;
    setLoading(true);
    setError(null);
    setData(null);
    try {
      const res = await fetch(`/api/lookup?username=${username}`);
      if (!res.ok) throw new Error("Player not found");
      const result = await res.json();
      setData(result);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6 flex flex-col items-center">
      <h1 className="text-4xl font-bold mb-6">Minecraft Tier Lookup</h1>
      <div className="flex items-center gap-2 w-full max-w-md">
        <Input
          placeholder="Enter Minecraft username..."
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <Button onClick={searchPlayer} disabled={loading}>
          {loading ? <Loader2 className="animate-spin" /> : "Search"}
        </Button>
      </div>
      {error && <p className="text-red-500 mt-4">{error}</p>}
      {data && (
        <Card className="bg-gray-900 text-white mt-6 w-full max-w-xl">
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold">{data.username}</h2>
            <p className="mt-2 text-sm">UUID: {data.uuid}</p>
            <div className="mt-4">
              {data.tiers.map((tier, index) => (
                <div key={index} className="border-t border-gray-700 py-2">
                  <p className="font-medium text-lg">{tier.mode}</p>
                  <p className="text-sm text-gray-400">Tier: {tier.rank}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}