export default function handler(req, res) {
  const { username } = req.query;
  if (!username) return res.status(400).json({ error: "No username" });

  res.status(200).json({
    username,
    uuid: "1234-5678-9012",
    tiers: [
      { mode: "Bedwars", rank: "S+" },
      { mode: "Skywars", rank: "A" }
    ]
  });
}